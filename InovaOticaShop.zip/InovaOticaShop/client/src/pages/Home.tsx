import { Link } from "wouter";
import { ArrowRight, Shield, Truck, CreditCard, Award, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductCard } from "@/components/ProductCard";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

const features = [
  {
    icon: Shield,
    title: "Garantia de 2 Anos",
    description: "Todos os produtos com garantia estendida",
  },
  {
    icon: Truck,
    title: "Frete Grátis",
    description: "Para compras acima de R$ 300",
  },
  {
    icon: CreditCard,
    title: "Parcelamento",
    description: "Em até 10x sem juros no cartão",
  },
  {
    icon: Award,
    title: "Qualidade Premium",
    description: "Apenas marcas renomadas",
  },
];

const categories = [
  {
    type: "sol",
    title: "Óculos de Sol",
    description: "Proteção e estilo para o seu dia a dia",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=600&h=400&fit=crop",
  },
  {
    type: "grau",
    title: "Óculos de Grau",
    description: "Armações modernas para sua receita",
    image: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=600&h=400&fit=crop",
  },
  {
    type: "esportivo",
    title: "Óculos Esportivos",
    description: "Performance para atletas exigentes",
    image: "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=600&h=400&fit=crop",
  },
];

export default function Home() {
  const { data: featuredProducts, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <section className="relative min-h-[600px] flex items-center overflow-hidden">
          <div className="absolute inset-0">
            <img
              src="https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=1920&h=1080&fit=crop"
              alt="Óculos modernos"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/80 to-transparent" />
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-2xl space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Enxergue o mundo com{" "}
                <span className="text-accent">estilo</span>
              </h1>
              <p className="text-lg md:text-xl text-white/90">
                Descubra nossa coleção exclusiva de óculos de sol, grau e esportivos.
                Qualidade premium com os melhores preços do mercado.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/produtos">
                  <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2" data-testid="button-hero-cta">
                    Adquirir Agora
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/sobre">
                  <Button size="lg" variant="outline" className="border-white/30 text-white bg-white/10 backdrop-blur-sm hover:bg-white/20">
                    Conheça a Inova
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="py-8 bg-muted/50 border-y border-border">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {features.map((feature) => (
                <div key={feature.title} className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-foreground">{feature.title}</h3>
                    <p className="text-xs text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-foreground">Produtos em Destaque</h2>
                <p className="text-muted-foreground mt-1">Os mais vendidos da nossa loja</p>
              </div>
              <Link href="/produtos">
                <Button variant="outline" className="gap-2" data-testid="button-view-all-products">
                  Ver todos os produtos
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i}>
                    <Skeleton className="aspect-square w-full" />
                    <CardContent className="p-4 space-y-3">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-5 w-full" />
                      <Skeleton className="h-4 w-24" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-6 w-20" />
                        <Skeleton className="h-9 w-9 rounded-md" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : featuredProducts && featuredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.slice(0, 8).map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">Nenhum produto em destaque no momento.</p>
              </Card>
            )}
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground">Explore nossas Categorias</h2>
              <p className="text-muted-foreground mt-2">Encontre o óculos perfeito para cada ocasião</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {categories.map((category) => (
                <Link key={category.type} href={`/produtos?type=${category.type}`}>
                  <Card className="group overflow-hidden hover-elevate cursor-pointer" data-testid={`card-category-${category.type}`}>
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img
                        src={category.image}
                        alt={category.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/50 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                        <h3 className="text-xl font-bold mb-1">{category.title}</h3>
                        <p className="text-sm text-white/80">{category.description}</p>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="bg-primary rounded-lg overflow-hidden">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="p-8 md:p-12 space-y-6">
                  <h2 className="text-2xl md:text-3xl font-bold text-white">
                    Por que escolher a Inova Ótica?
                  </h2>
                  <ul className="space-y-4">
                    {[
                      "Mais de 20 anos de experiência no mercado",
                      "Equipe de optometristas qualificados",
                      "Marcas internacionais renomadas",
                      "Atendimento personalizado e humanizado",
                      "Laboratório próprio para lentes especiais",
                    ].map((item) => (
                      <li key={item} className="flex items-center gap-3 text-white/90">
                        <div className="w-2 h-2 rounded-full bg-accent" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/sobre">
                    <Button variant="secondary" className="mt-4">
                      Saiba mais sobre nós
                    </Button>
                  </Link>
                </div>
                <div className="hidden md:block h-full">
                  <img
                    src="https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=600&h=500&fit=crop"
                    alt="Loja Inova Ótica"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Pronto para encontrar seu óculos ideal?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Navegue pelo nosso catálogo completo e encontre o modelo perfeito para você.
              Frete grátis para compras acima de R$ 300 e parcelamento em até 10x sem juros.
            </p>
            <Link href="/produtos">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2" data-testid="button-cta-catalog">
                Ver Catálogo Completo
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
