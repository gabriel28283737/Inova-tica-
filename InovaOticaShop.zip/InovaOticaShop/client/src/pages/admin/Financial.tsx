import { useMemo } from "react";
import { DollarSign, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Wallet, CreditCard, Receipt } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import type { Order, FinancialTransaction } from "@shared/schema";

export default function AdminFinancial() {
  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<FinancialTransaction[]>({
    queryKey: ["/api/financial/transactions"],
  });

  const financialStats = useMemo(() => {
    if (!orders) return null;

    const completedOrders = orders.filter((o) => o.status === "delivered" || o.status === "confirmed");
    const totalRevenue = completedOrders.reduce((sum, o) => sum + o.total, 0);
    
    const expenses = transactions?.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0) || 0;
    const netProfit = totalRevenue - expenses;

    const today = new Date();
    const thisMonth = completedOrders.filter((o) => {
      const orderDate = new Date(o.createdAt);
      return orderDate.getMonth() === today.getMonth() && orderDate.getFullYear() === today.getFullYear();
    });
    
    const lastMonth = completedOrders.filter((o) => {
      const orderDate = new Date(o.createdAt);
      const lastMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return orderDate.getMonth() === lastMonthDate.getMonth() && orderDate.getFullYear() === lastMonthDate.getFullYear();
    });

    const thisMonthRevenue = thisMonth.reduce((sum, o) => sum + o.total, 0);
    const lastMonthRevenue = lastMonth.reduce((sum, o) => sum + o.total, 0);
    const revenueGrowth = lastMonthRevenue > 0 ? ((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 : 0;

    return {
      totalRevenue,
      thisMonthRevenue,
      lastMonthRevenue,
      revenueGrowth,
      expenses,
      netProfit,
      profitMargin: totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0,
      pendingPayments: orders.filter((o) => o.status === "pending").reduce((sum, o) => sum + o.total, 0),
    };
  }, [orders, transactions]);

  const monthlyData = useMemo(() => {
    if (!orders) return [];

    const months: { [key: string]: { receitas: number; despesas: number; lucro: number } } = {};
    const now = new Date();

    for (let i = 11; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = date.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
      months[key] = { receitas: 0, despesas: 0, lucro: 0 };
    }

    orders.forEach((order) => {
      if (order.status === "delivered" || order.status === "confirmed") {
        const date = new Date(order.createdAt);
        const key = date.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
        if (months[key]) {
          months[key].receitas += order.total;
        }
      }
    });

    transactions?.forEach((transaction) => {
      const date = new Date(transaction.createdAt);
      const key = date.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
      if (months[key]) {
        if (transaction.type === "expense") {
          months[key].despesas += transaction.amount;
        }
      }
    });

    return Object.entries(months).map(([name, data]) => ({
      name,
      receitas: data.receitas,
      despesas: data.despesas,
      lucro: data.receitas - data.despesas,
    }));
  }, [orders, transactions]);

  const cashFlowData = useMemo(() => {
    if (!orders) return [];

    const days: { [key: string]: { entrada: number; saida: number } } = {};
    const now = new Date();

    for (let i = 29; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const key = date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
      days[key] = { entrada: 0, saida: 0 };
    }

    orders.forEach((order) => {
      if (order.status === "delivered" || order.status === "confirmed") {
        const date = new Date(order.createdAt);
        const key = date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
        if (days[key]) {
          days[key].entrada += order.total;
        }
      }
    });

    transactions?.forEach((transaction) => {
      const date = new Date(transaction.createdAt);
      const key = date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
      if (days[key]) {
        if (transaction.type === "expense") {
          days[key].saida += transaction.amount;
        }
      }
    });

    return Object.entries(days).map(([name, data]) => ({
      name,
      ...data,
    }));
  }, [orders, transactions]);

  const recentTransactions = useMemo(() => {
    const allTransactions: Array<{
      id: string;
      type: "income" | "expense";
      description: string;
      amount: number;
      date: string;
      category: string;
    }> = [];

    orders?.forEach((order) => {
      if (order.status === "delivered" || order.status === "confirmed") {
        allTransactions.push({
          id: order.id,
          type: "income",
          description: `Pedido #${order.orderNumber}`,
          amount: order.total,
          date: order.createdAt,
          category: "Vendas",
        });
      }
    });

    transactions?.forEach((transaction) => {
      allTransactions.push({
        id: transaction.id,
        type: transaction.type,
        description: transaction.description,
        amount: transaction.amount,
        date: transaction.createdAt,
        category: transaction.category,
      });
    });

    return allTransactions
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
  }, [orders, transactions]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const isLoading = ordersLoading || transactionsLoading;

  return (
    <AdminLayout title="Dashboard Financeiro" subtitle="Visão geral das finanças do negócio">
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Receita Total
              </CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-32" />
              ) : (
                <>
                  <div className="text-2xl font-bold text-green-600" data-testid="text-total-revenue">
                    {formatPrice(financialStats?.totalRevenue || 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Total acumulado
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Receita do Mês
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-28" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid="text-monthly-revenue">
                    {formatPrice(financialStats?.thisMonthRevenue || 0)}
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(financialStats?.revenueGrowth || 0) >= 0 ? (
                      <ArrowUpRight className="h-3 w-3 text-green-600" />
                    ) : (
                      <ArrowDownRight className="h-3 w-3 text-red-600" />
                    )}
                    <span className={(financialStats?.revenueGrowth || 0) >= 0 ? "text-green-600" : "text-red-600"}>
                      {Math.abs(financialStats?.revenueGrowth || 0).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">vs mês anterior</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Despesas
              </CardTitle>
              <Receipt className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-28" />
              ) : (
                <>
                  <div className="text-2xl font-bold text-red-600" data-testid="text-expenses">
                    {formatPrice(financialStats?.expenses || 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Total de despesas
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Lucro Líquido
              </CardTitle>
              <Wallet className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-28" />
              ) : (
                <>
                  <div className="text-2xl font-bold text-accent" data-testid="text-net-profit">
                    {formatPrice(financialStats?.netProfit || 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Margem: {financialStats?.profitMargin.toFixed(1)}%
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Receitas vs Despesas (12 meses)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : monthlyData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="name" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(value) => `R$${(value / 1000).toFixed(0)}k`} />
                    <Tooltip
                      formatter={(value: number) => [formatPrice(value), ""]}
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Bar dataKey="receitas" name="Receitas" fill="hsl(142, 76%, 36%)" radius={4} />
                    <Bar dataKey="despesas" name="Despesas" fill="hsl(0, 84%, 60%)" radius={4} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5 text-accent" />
                Fluxo de Caixa (30 dias)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : cashFlowData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="name" className="text-xs" interval={4} />
                    <YAxis className="text-xs" tickFormatter={(value) => `R$${value}`} />
                    <Tooltip
                      formatter={(value: number) => [formatPrice(value), ""]}
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="entrada"
                      name="Entradas"
                      stroke="hsl(142, 76%, 36%)"
                      fill="hsl(142, 76%, 36%)"
                      fillOpacity={0.3}
                    />
                    <Area
                      type="monotone"
                      dataKey="saida"
                      name="Saídas"
                      stroke="hsl(0, 84%, 60%)"
                      fill="hsl(0, 84%, 60%)"
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Movimentações Recentes
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : recentTransactions.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="text-sm text-muted-foreground">
                        {formatDate(transaction.date)}
                      </TableCell>
                      <TableCell className="font-medium">
                        {transaction.description}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{transaction.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={transaction.type === "income" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"}>
                          {transaction.type === "income" ? "Entrada" : "Saída"}
                        </Badge>
                      </TableCell>
                      <TableCell className={`text-right font-medium ${transaction.type === "income" ? "text-green-600" : "text-red-600"}`}>
                        {transaction.type === "income" ? "+" : "-"}{formatPrice(transaction.amount)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                Nenhuma movimentação registrada.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
