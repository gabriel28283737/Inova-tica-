import { useState } from "react";
import { Search, Eye, Plus, Edit2, Trash2, Clock, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import type { Customer, CustomerObservation } from "@shared/schema";

export default function AdminCustomers() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [newObservation, setNewObservation] = useState("");
  const [editingObservation, setEditingObservation] = useState<CustomerObservation | null>(null);
  const [editObservationContent, setEditObservationContent] = useState("");

  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const addObservationMutation = useMutation({
    mutationFn: async ({ customerId, content }: { customerId: string; content: string }) => {
      return apiRequest("POST", `/api/customers/${customerId}/observations`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      setNewObservation("");
      toast({ title: "Observação adicionada com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao adicionar observação", variant: "destructive" });
    },
  });

  const updateObservationMutation = useMutation({
    mutationFn: async ({ customerId, observationId, content }: { customerId: string; observationId: string; content: string }) => {
      return apiRequest("PATCH", `/api/customers/${customerId}/observations/${observationId}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      setEditingObservation(null);
      setEditObservationContent("");
      toast({ title: "Observação atualizada com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao atualizar observação", variant: "destructive" });
    },
  });

  const deleteObservationMutation = useMutation({
    mutationFn: async ({ customerId, observationId }: { customerId: string; observationId: string }) => {
      return apiRequest("DELETE", `/api/customers/${customerId}/observations/${observationId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      toast({ title: "Observação removida com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao remover observação", variant: "destructive" });
    },
  });

  const filteredCustomers = customers?.filter((customer) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      customer.name.toLowerCase().includes(query) ||
      customer.email.toLowerCase().includes(query) ||
      customer.cpf.includes(query)
    );
  }) || [];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const handleAddObservation = () => {
    if (!selectedCustomer || !newObservation.trim()) return;
    addObservationMutation.mutate({
      customerId: selectedCustomer.id,
      content: newObservation.trim(),
    });
  };

  const handleEditObservation = (obs: CustomerObservation) => {
    setEditingObservation(obs);
    setEditObservationContent(obs.content);
  };

  const handleSaveEditObservation = () => {
    if (!selectedCustomer || !editingObservation || !editObservationContent.trim()) return;
    updateObservationMutation.mutate({
      customerId: selectedCustomer.id,
      observationId: editingObservation.id,
      content: editObservationContent.trim(),
    });
  };

  const handleDeleteObservation = (observationId: string) => {
    if (!selectedCustomer) return;
    deleteObservationMutation.mutate({
      customerId: selectedCustomer.id,
      observationId,
    });
  };

  const openCustomerDetails = (customer: Customer) => {
    setSelectedCustomer(customer);
    setDetailsOpen(true);
    setNewObservation("");
    setEditingObservation(null);
  };

  return (
    <AdminLayout title="Gerenciamento de Clientes" subtitle="Visualize e gerencie informações dos clientes">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, e-mail ou CPF..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-customers"
            />
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">
              Clientes ({filteredCustomers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : filteredCustomers.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>CPF</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead>Cidade/UF</TableHead>
                      <TableHead>Pedidos</TableHead>
                      <TableHead>Total Gasto</TableHead>
                      <TableHead>Cadastro</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCustomers.map((customer) => (
                      <TableRow key={customer.id} data-testid={`row-customer-${customer.id}`}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-sm text-muted-foreground">{customer.email}</p>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {customer.cpf}
                        </TableCell>
                        <TableCell className="text-sm">
                          {customer.phone}
                        </TableCell>
                        <TableCell className="text-sm">
                          {customer.address.city}/{customer.address.state}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{customer.totalOrders}</Badge>
                        </TableCell>
                        <TableCell className="font-medium text-accent">
                          {formatPrice(customer.totalSpent)}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDate(customer.createdAt)}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openCustomerDetails(customer)}
                            data-testid={`button-view-customer-${customer.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                Nenhum cliente encontrado.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              {selectedCustomer?.name}
            </DialogTitle>
            <DialogDescription>
              Cliente desde {selectedCustomer && formatDate(selectedCustomer.createdAt)}
            </DialogDescription>
          </DialogHeader>
          
          {selectedCustomer && (
            <div className="flex-1 overflow-hidden flex flex-col gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Informações de Contato</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1 text-sm">
                    <p><span className="text-muted-foreground">E-mail:</span> {selectedCustomer.email}</p>
                    <p><span className="text-muted-foreground">Telefone:</span> {selectedCustomer.phone}</p>
                    <p><span className="text-muted-foreground">CPF:</span> {selectedCustomer.cpf}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Endereço</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1 text-sm">
                    <p>{selectedCustomer.address.street}, {selectedCustomer.address.number}</p>
                    {selectedCustomer.address.complement && <p>{selectedCustomer.address.complement}</p>}
                    <p>{selectedCustomer.address.neighborhood}</p>
                    <p>{selectedCustomer.address.city}/{selectedCustomer.address.state} - CEP: {selectedCustomer.address.zipCode}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex items-center gap-4">
                <Badge variant="outline" className="px-4 py-2">
                  <span className="text-muted-foreground mr-2">Pedidos:</span>
                  <span className="font-bold">{selectedCustomer.totalOrders}</span>
                </Badge>
                <Badge variant="outline" className="px-4 py-2">
                  <span className="text-muted-foreground mr-2">Total Gasto:</span>
                  <span className="font-bold text-accent">{formatPrice(selectedCustomer.totalSpent)}</span>
                </Badge>
              </div>

              <Separator />

              <div className="flex-1 overflow-hidden flex flex-col">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  Observações do Cliente
                  <Badge variant="secondary">{selectedCustomer.observations?.length || 0}</Badge>
                </h4>

                <div className="mb-4">
                  <div className="flex gap-2">
                    <Textarea
                      placeholder="Adicione uma observação sobre este cliente..."
                      value={newObservation}
                      onChange={(e) => setNewObservation(e.target.value)}
                      className="flex-1"
                      rows={2}
                      data-testid="input-new-observation"
                    />
                    <Button
                      onClick={handleAddObservation}
                      disabled={!newObservation.trim() || addObservationMutation.isPending}
                      data-testid="button-add-observation"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Adicionar
                    </Button>
                  </div>
                </div>

                <ScrollArea className="flex-1 -mx-6 px-6">
                  <div className="space-y-3">
                    {selectedCustomer.observations && selectedCustomer.observations.length > 0 ? (
                      selectedCustomer.observations.map((obs) => (
                        <Card key={obs.id} className="bg-muted/50" data-testid={`observation-${obs.id}`}>
                          <CardContent className="p-4">
                            {editingObservation?.id === obs.id ? (
                              <div className="space-y-2">
                                <Textarea
                                  value={editObservationContent}
                                  onChange={(e) => setEditObservationContent(e.target.value)}
                                  rows={3}
                                  data-testid="input-edit-observation"
                                />
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    onClick={handleSaveEditObservation}
                                    disabled={updateObservationMutation.isPending}
                                    data-testid="button-save-observation"
                                  >
                                    Salvar
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingObservation(null)}
                                  >
                                    Cancelar
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <>
                                <p className="text-sm mb-3">{obs.content}</p>
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <Clock className="h-3 w-3" />
                                    <span>{formatDateTime(obs.createdAt)}</span>
                                    <span>-</span>
                                    <span>{obs.authorName}</span>
                                    <span className="text-muted-foreground/60">({obs.authorEmail})</span>
                                  </div>
                                  {obs.authorId === user?.id && (
                                    <div className="flex gap-1">
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-7 w-7"
                                        onClick={() => handleEditObservation(obs)}
                                        data-testid={`button-edit-observation-${obs.id}`}
                                      >
                                        <Edit2 className="h-3 w-3" />
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-7 w-7 text-destructive"
                                        onClick={() => handleDeleteObservation(obs.id)}
                                        data-testid={`button-delete-observation-${obs.id}`}
                                      >
                                        <Trash2 className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  )}
                                </div>
                              </>
                            )}
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        Nenhuma observação registrada para este cliente.
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
