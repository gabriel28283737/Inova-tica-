import { useState } from "react";
import { Search, UserMinus, Shield, AlertTriangle, User, Mail, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import type { Permission } from "@shared/schema";
import { ROLES, ROLE_NAMES, ADMIN_EMAIL } from "@shared/schema";

export default function AdminRemovePermissions() {
  const { toast } = useToast();
  const { user } = useAuth();
  const userRole = user?.email === ADMIN_EMAIL ? ROLES.ADMIN : (user?.role || 0);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPermission, setSelectedPermission] = useState<Permission | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const { data: permissions, isLoading } = useQuery<Permission[]>({
    queryKey: ["/api/permissions"],
  });

  const removePermissionMutation = useMutation({
    mutationFn: async (permissionId: string) => {
      return apiRequest("DELETE", `/api/permissions/${permissionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions"] });
      setConfirmOpen(false);
      setSelectedPermission(null);
      setConfirmed(false);
      toast({ title: "Permissão removida com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: error.message || "Erro ao remover permissão", variant: "destructive" });
    },
  });

  const activePermissions = permissions?.filter((p) => p.isActive) || [];

  const filteredPermissions = activePermissions.filter((permission) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      permission.userName.toLowerCase().includes(query) ||
      permission.userEmail.toLowerCase().includes(query)
    );
  });

  const canRemove = (permission: Permission) => {
    if (permission.userEmail === ADMIN_EMAIL) return false;
    if (user?.email === ADMIN_EMAIL) return true;
    return userRole > permission.role;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const handleRemoveClick = (permission: Permission) => {
    setSelectedPermission(permission);
    setConfirmed(false);
    setConfirmOpen(true);
  };

  const handleConfirmRemove = () => {
    if (!selectedPermission || !confirmed) return;
    removePermissionMutation.mutate(selectedPermission.id);
  };

  return (
    <AdminLayout title="Remover Permissões de Usuários" subtitle="Gerencie e remova permissões administrativas">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou e-mail..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-permissions"
            />
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="h-5 w-5 text-primary" />
              Usuários com Permissões Administrativas
              <Badge variant="secondary">{filteredPermissions.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : filteredPermissions.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Usuário</TableHead>
                      <TableHead>E-mail</TableHead>
                      <TableHead>Cargo</TableHead>
                      <TableHead>Data de Adição</TableHead>
                      <TableHead>Adicionado Por</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPermissions.map((permission) => (
                      <TableRow key={permission.id} data-testid={`row-permission-${permission.id}`}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            {permission.userName}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-muted-foreground" />
                            {permission.userEmail}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-accent border-accent">
                            {ROLE_NAMES[permission.role]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            {formatDate(permission.createdAt)}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div>
                            <p>{permission.addedByName}</p>
                            <p className="text-muted-foreground text-xs">{permission.addedByEmail}</p>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleRemoveClick(permission)}
                            disabled={!canRemove(permission)}
                            data-testid={`button-remove-permission-${permission.id}`}
                          >
                            <UserMinus className="h-4 w-4 mr-1" />
                            Remover
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                Nenhum usuário com permissões administrativas encontrado.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Confirmar Remoção de Permissão
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja remover as permissões administrativas deste usuário?
            </DialogDescription>
          </DialogHeader>
          
          {selectedPermission && (
            <div className="space-y-4">
              <Card className="bg-destructive/5 border-destructive/20">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{selectedPermission.userName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{selectedPermission.userEmail}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <Badge variant="outline">{ROLE_NAMES[selectedPermission.role]}</Badge>
                  </div>
                </CardContent>
              </Card>

              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-md">
                <Checkbox
                  id="confirm-remove"
                  checked={confirmed}
                  onCheckedChange={(checked) => setConfirmed(checked as boolean)}
                  data-testid="checkbox-confirm-remove"
                />
                <Label htmlFor="confirm-remove" className="text-sm cursor-pointer">
                  Sim, confirmo que desejo remover este usuário
                </Label>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmRemove}
              disabled={!confirmed || removePermissionMutation.isPending}
              data-testid="button-confirm-remove-permission"
            >
              {removePermissionMutation.isPending ? "Removendo..." : "Confirmar Remoção"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
