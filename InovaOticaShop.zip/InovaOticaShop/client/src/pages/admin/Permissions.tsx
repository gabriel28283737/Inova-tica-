import { useState } from "react";
import { UserPlus, Clock, User, Mail, Shield, CheckCircle, XCircle } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import type { Permission } from "@shared/schema";
import { ROLES, ROLE_NAMES, ADMIN_EMAIL } from "@shared/schema";

const addPermissionSchema = z.object({
  email: z.string().email("E-mail inválido"),
  name: z.string().min(2, "Nome deve ter no mínimo 2 caracteres"),
  role: z.string().min(1, "Selecione um cargo"),
});

type AddPermissionInput = z.infer<typeof addPermissionSchema>;

export default function AdminPermissions() {
  const { toast } = useToast();
  const { user } = useAuth();
  const userRole = user?.email === ADMIN_EMAIL ? ROLES.ADMIN : (user?.role || 0);

  const form = useForm<AddPermissionInput>({
    resolver: zodResolver(addPermissionSchema),
    defaultValues: {
      email: "",
      name: "",
      role: "",
    },
  });

  const { data: permissions, isLoading } = useQuery<Permission[]>({
    queryKey: ["/api/permissions"],
  });

  const addPermissionMutation = useMutation({
    mutationFn: async (data: AddPermissionInput) => {
      return apiRequest("POST", "/api/permissions", {
        ...data,
        role: parseInt(data.role),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions"] });
      form.reset();
      toast({ title: "Permissão adicionada com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: error.message || "Erro ao adicionar permissão", variant: "destructive" });
    },
  });

  const availableRoles = Object.entries(ROLES)
    .filter(([_, value]) => typeof value === "number" && value <= userRole && value !== ROLES.ADMIN)
    .map(([key, value]) => ({
      value: String(value),
      label: ROLE_NAMES[value as number] || key,
    }));

  const onSubmit = (data: AddPermissionInput) => {
    addPermissionMutation.mutate(data);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const activePermissions = permissions?.filter((p) => p.isActive) || [];

  return (
    <AdminLayout title="Gerenciar Permissões de Usuários" subtitle="Adicione permissões administrativas">
      <div className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-primary" />
              Adicionar Nova Permissão
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>E-mail do Usuário</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="usuario@email.com"
                            {...field}
                            data-testid="input-permission-email"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome Completo</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Nome do usuário"
                            {...field}
                            data-testid="input-permission-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cargo</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-permission-role">
                              <SelectValue placeholder="Selecione o cargo" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {availableRoles.map((role) => (
                              <SelectItem key={role.value} value={role.value}>
                                {role.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <Button
                  type="submit"
                  disabled={addPermissionMutation.isPending}
                  data-testid="button-add-permission"
                >
                  {addPermissionMutation.isPending ? "Adicionando..." : "Adicionar Permissão"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Histórico de Permissões Adicionadas
            <Badge variant="secondary">{activePermissions.length}</Badge>
          </h2>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-48 w-full" />
              ))}
            </div>
          ) : activePermissions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {activePermissions.map((permission, index) => (
                <Card
                  key={permission.id}
                  className={index % 2 === 0 ? "bg-primary/5 border-white" : "bg-white dark:bg-card border-white"}
                  data-testid={`card-permission-${permission.id}`}
                >
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge variant={permission.isActive ? "default" : "secondary"} className="gap-1">
                        {permission.isActive ? (
                          <>
                            <CheckCircle className="h-3 w-3" />
                            Ativo
                          </>
                        ) : (
                          <>
                            <XCircle className="h-3 w-3" />
                            Inativo
                          </>
                        )}
                      </Badge>
                      <Badge variant="outline" className="text-accent border-accent">
                        {ROLE_NAMES[permission.role]}
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <div className="p-2 bg-muted/50 rounded-md">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Usuário Adicionado</p>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium text-sm">{permission.userName}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">{permission.userEmail}</span>
                        </div>
                      </div>

                      <div className="p-2 bg-muted/50 rounded-md">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Adicionado Por</p>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium text-sm">{permission.addedByName}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">{permission.addedByEmail}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t">
                      <Clock className="h-3 w-3" />
                      <span>{formatDateTime(permission.createdAt)}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <p className="text-muted-foreground">
                Nenhuma permissão registrada ainda.
              </p>
            </Card>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
