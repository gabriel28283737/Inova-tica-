import { useMemo } from "react";
import { TrendingUp, TrendingDown, ShoppingCart, DollarSign, Users, Package, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import type { Order, Product } from "@shared/schema";

const COLORS = ["hsl(235, 85%, 30%)", "hsl(4, 85%, 64%)", "hsl(200, 70%, 45%)", "hsl(280, 65%, 50%)", "hsl(25, 95%, 53%)"];

export default function AdminDashboard() {
  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const stats = useMemo(() => {
    if (!orders) return null;

    const today = new Date();
    const thisMonth = orders.filter((o) => {
      const orderDate = new Date(o.createdAt);
      return orderDate.getMonth() === today.getMonth() && orderDate.getFullYear() === today.getFullYear();
    });

    const lastMonth = orders.filter((o) => {
      const orderDate = new Date(o.createdAt);
      const lastMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return orderDate.getMonth() === lastMonthDate.getMonth() && orderDate.getFullYear() === lastMonthDate.getFullYear();
    });

    const totalSales = orders.reduce((sum, o) => sum + o.total, 0);
    const thisMonthSales = thisMonth.reduce((sum, o) => sum + o.total, 0);
    const lastMonthSales = lastMonth.reduce((sum, o) => sum + o.total, 0);
    const salesGrowth = lastMonthSales > 0 ? ((thisMonthSales - lastMonthSales) / lastMonthSales) * 100 : 0;

    const avgTicket = orders.length > 0 ? totalSales / orders.length : 0;
    const thisMonthOrders = thisMonth.length;
    const lastMonthOrders = lastMonth.length;
    const ordersGrowth = lastMonthOrders > 0 ? ((thisMonthOrders - lastMonthOrders) / lastMonthOrders) * 100 : 0;

    return {
      totalSales,
      thisMonthSales,
      salesGrowth,
      totalOrders: orders.length,
      thisMonthOrders,
      ordersGrowth,
      avgTicket,
      pendingOrders: orders.filter((o) => o.status === "pending").length,
    };
  }, [orders]);

  const salesByMonth = useMemo(() => {
    if (!orders) return [];

    const months: { [key: string]: number } = {};
    const now = new Date();

    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = date.toLocaleDateString("pt-BR", { month: "short" });
      months[key] = 0;
    }

    orders.forEach((order) => {
      const date = new Date(order.createdAt);
      const key = date.toLocaleDateString("pt-BR", { month: "short" });
      if (months[key] !== undefined) {
        months[key] += order.total;
      }
    });

    return Object.entries(months).map(([name, vendas]) => ({ name, vendas }));
  }, [orders]);

  const salesByCategory = useMemo(() => {
    if (!orders || !products) return [];

    const categories: { [key: string]: number } = {
      sol: 0,
      grau: 0,
      esportivo: 0,
    };

    orders.forEach((order) => {
      order.items.forEach((item) => {
        const product = products.find((p) => p.id === item.productId);
        if (product) {
          categories[product.type] += item.quantity * item.price;
        }
      });
    });

    return [
      { name: "Óculos de Sol", value: categories.sol },
      { name: "Óculos de Grau", value: categories.grau },
      { name: "Óculos Esportivos", value: categories.esportivo },
    ].filter((c) => c.value > 0);
  }, [orders, products]);

  const topProducts = useMemo(() => {
    if (!orders || !products) return [];

    const productSales: { [key: string]: { name: string; quantity: number; revenue: number } } = {};

    orders.forEach((order) => {
      order.items.forEach((item) => {
        if (!productSales[item.productId]) {
          productSales[item.productId] = { name: item.productName, quantity: 0, revenue: 0 };
        }
        productSales[item.productId].quantity += item.quantity;
        productSales[item.productId].revenue += item.quantity * item.price;
      });
    });

    return Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [orders, products]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const isLoading = ordersLoading || productsLoading;

  return (
    <AdminLayout title="Dashboard" subtitle="Visão geral do seu negócio">
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Vendas do Mês
              </CardTitle>
              <DollarSign className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-32" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid="text-monthly-sales">
                    {formatPrice(stats?.thisMonthSales || 0)}
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(stats?.salesGrowth || 0) >= 0 ? (
                      <TrendingUp className="h-3 w-3 text-green-600" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-red-600" />
                    )}
                    <span className={(stats?.salesGrowth || 0) >= 0 ? "text-green-600" : "text-red-600"}>
                      {Math.abs(stats?.salesGrowth || 0).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">vs mês anterior</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pedidos do Mês
              </CardTitle>
              <ShoppingCart className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid="text-monthly-orders">
                    {stats?.thisMonthOrders || 0}
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    {(stats?.ordersGrowth || 0) >= 0 ? (
                      <TrendingUp className="h-3 w-3 text-green-600" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-red-600" />
                    )}
                    <span className={(stats?.ordersGrowth || 0) >= 0 ? "text-green-600" : "text-red-600"}>
                      {Math.abs(stats?.ordersGrowth || 0).toFixed(1)}%
                    </span>
                    <span className="text-muted-foreground">vs mês anterior</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Ticket Médio
              </CardTitle>
              <BarChart3 className="h-4 w-4 text-chart-3" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-28" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid="text-avg-ticket">
                    {formatPrice(stats?.avgTicket || 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Base: {stats?.totalOrders || 0} pedidos
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 gap-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pedidos Pendentes
              </CardTitle>
              <Package className="h-4 w-4 text-chart-5" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid="text-pending-orders">
                    {stats?.pendingOrders || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Aguardando processamento
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Evolução de Vendas
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : salesByMonth.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={salesByMonth}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="name" className="text-xs" />
                    <YAxis
                      className="text-xs"
                      tickFormatter={(value) => `R$${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(value: number) => [formatPrice(value), "Vendas"]}
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="vendas"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-accent" />
                Vendas por Categoria
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : salesByCategory.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={salesByCategory}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {salesByCategory.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => [formatPrice(value), "Vendas"]}
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  Nenhum dado disponível
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-chart-3" />
              Produtos Mais Vendidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : topProducts.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topProducts} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis type="number" tickFormatter={(value) => formatPrice(value)} />
                  <YAxis type="category" dataKey="name" width={150} className="text-xs" />
                  <Tooltip
                    formatter={(value: number, name: string) => [
                      name === "revenue" ? formatPrice(value) : value,
                      name === "revenue" ? "Faturamento" : "Quantidade",
                    ]}
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="revenue" name="Faturamento" fill="hsl(var(--primary))" radius={4} />
                  <Bar dataKey="quantity" name="Quantidade" fill="hsl(var(--accent))" radius={4} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
