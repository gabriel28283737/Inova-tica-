import { useState } from "react";
import { Search, Filter, Eye, RotateCcw, Truck, Package, CheckCircle, XCircle, Clock, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AdminLayout } from "@/components/AdminSidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Order } from "@shared/schema";
import { ORDER_STATUS_LABELS, PAYMENT_METHOD_LABELS } from "@shared/schema";

const statusColors: { [key: string]: string } = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  confirmed: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  separating: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  shipped: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400",
  delivered: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const statusIcons: { [key: string]: React.ElementType } = {
  pending: Clock,
  confirmed: CheckCircle,
  separating: Package,
  shipped: Truck,
  delivered: CheckCircle,
  cancelled: XCircle,
};

export default function AdminSales() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);
  const [refundReason, setRefundReason] = useState("");
  const [refundAmount, setRefundAmount] = useState("");
  const [isPartialRefund, setIsPartialRefund] = useState(false);

  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: string; status: string }) => {
      return apiRequest("PATCH", `/api/orders/${orderId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ title: "Status atualizado com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao atualizar status", variant: "destructive" });
    },
  });

  const requestRefundMutation = useMutation({
    mutationFn: async (data: { orderId: string; reason: string; amount: number; isPartial: boolean }) => {
      return apiRequest("POST", "/api/refunds", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/refunds"] });
      setRefundOpen(false);
      setRefundReason("");
      setRefundAmount("");
      setIsPartialRefund(false);
      toast({ title: "Reembolso solicitado com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao solicitar reembolso", variant: "destructive" });
    },
  });

  const filteredOrders = orders?.filter((order) => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (!order.orderNumber.toLowerCase().includes(query) &&
          !order.customerName.toLowerCase().includes(query) &&
          !order.customerEmail.toLowerCase().includes(query)) {
        return false;
      }
    }
    if (statusFilter !== "all" && order.status !== statusFilter) {
      return false;
    }
    return true;
  }) || [];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const handleStatusChange = (orderId: string, status: string) => {
    updateStatusMutation.mutate({ orderId, status });
  };

  const handleRefundSubmit = () => {
    if (!selectedOrder || !refundReason) return;
    
    const amount = isPartialRefund ? parseFloat(refundAmount) : selectedOrder.total;
    if (isNaN(amount) || amount <= 0 || amount > selectedOrder.total) {
      toast({ title: "Valor inválido", variant: "destructive" });
      return;
    }

    requestRefundMutation.mutate({
      orderId: selectedOrder.id,
      reason: refundReason,
      amount,
      isPartial: isPartialRefund,
    });
  };

  return (
    <AdminLayout title="Gerenciamento de Vendas" subtitle="Gerencie todos os pedidos da loja">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por número do pedido, cliente ou e-mail..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-orders"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[200px]" data-testid="select-status-filter">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              {Object.entries(ORDER_STATUS_LABELS).map(([value, label]) => (
                <SelectItem key={value} value={value}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">
              Pedidos ({filteredOrders.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : filteredOrders.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Pagamento</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => {
                      const StatusIcon = statusIcons[order.status] || Clock;
                      return (
                        <TableRow key={order.id} data-testid={`row-order-${order.id}`}>
                          <TableCell className="font-medium">
                            #{order.orderNumber}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{order.customerName}</p>
                              <p className="text-sm text-muted-foreground">{order.customerEmail}</p>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(order.createdAt)}
                          </TableCell>
                          <TableCell className="font-medium text-accent">
                            {formatPrice(order.total)}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {PAYMENT_METHOD_LABELS[order.paymentMethod]}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[order.status]}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {ORDER_STATUS_LABELS[order.status]}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => { setSelectedOrder(order); setDetailsOpen(true); }}
                                data-testid={`button-view-order-${order.id}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="outline" size="sm" data-testid={`button-change-status-${order.id}`}>
                                    Status
                                    <ChevronDown className="h-4 w-4 ml-1" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  {Object.entries(ORDER_STATUS_LABELS).map(([value, label]) => (
                                    <DropdownMenuItem
                                      key={value}
                                      onClick={() => handleStatusChange(order.id, value)}
                                      disabled={order.status === value}
                                    >
                                      {label}
                                    </DropdownMenuItem>
                                  ))}
                                </DropdownMenuContent>
                              </DropdownMenu>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => { setSelectedOrder(order); setRefundOpen(true); }}
                                disabled={order.status === "cancelled"}
                                data-testid={`button-refund-${order.id}`}
                              >
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                Nenhum pedido encontrado.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido #{selectedOrder?.orderNumber}</DialogTitle>
            <DialogDescription>
              Pedido realizado em {selectedOrder && formatDate(selectedOrder.createdAt)}
            </DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Cliente</h4>
                  <p>{selectedOrder.customerName}</p>
                  <p className="text-sm text-muted-foreground">{selectedOrder.customerEmail}</p>
                  <p className="text-sm text-muted-foreground">{selectedOrder.customerPhone}</p>
                  <p className="text-sm text-muted-foreground">CPF: {selectedOrder.customerCpf}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Endereço de Entrega</h4>
                  <p className="text-sm">
                    {selectedOrder.shippingAddress.street}, {selectedOrder.shippingAddress.number}
                    {selectedOrder.shippingAddress.complement && ` - ${selectedOrder.shippingAddress.complement}`}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {selectedOrder.shippingAddress.neighborhood} - {selectedOrder.shippingAddress.city}/{selectedOrder.shippingAddress.state}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    CEP: {selectedOrder.shippingAddress.zipCode}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Itens do Pedido</h4>
                <div className="space-y-2">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-muted/50 rounded-md">
                      <div>
                        <p className="font-medium">{item.productName}</p>
                        <p className="text-sm text-muted-foreground">Qtd: {item.quantity}</p>
                      </div>
                      <p className="font-medium">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span>Subtotal</span>
                  <span>{formatPrice(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Frete</span>
                  <span>{selectedOrder.shipping === 0 ? "Grátis" : formatPrice(selectedOrder.shipping)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-accent">{formatPrice(selectedOrder.total)}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-sm text-muted-foreground">Pagamento: </span>
                  <Badge variant="outline">{PAYMENT_METHOD_LABELS[selectedOrder.paymentMethod]}</Badge>
                </div>
                <Badge className={statusColors[selectedOrder.status]}>
                  {ORDER_STATUS_LABELS[selectedOrder.status]}
                </Badge>
              </div>

              {selectedOrder.trackingCode && (
                <div className="p-3 bg-muted/50 rounded-md">
                  <span className="text-sm text-muted-foreground">Código de Rastreamento: </span>
                  <span className="font-mono font-medium">{selectedOrder.trackingCode}</span>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={refundOpen} onOpenChange={setRefundOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Solicitar Reembolso</DialogTitle>
            <DialogDescription>
              Pedido #{selectedOrder?.orderNumber} - Total: {selectedOrder && formatPrice(selectedOrder.total)}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="refund-reason">Motivo do Reembolso *</Label>
              <Textarea
                id="refund-reason"
                placeholder="Descreva o motivo do reembolso..."
                value={refundReason}
                onChange={(e) => setRefundReason(e.target.value)}
                className="mt-1"
                data-testid="input-refund-reason"
              />
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="partial-refund"
                checked={isPartialRefund}
                onCheckedChange={(checked) => setIsPartialRefund(checked as boolean)}
                data-testid="checkbox-partial-refund"
              />
              <Label htmlFor="partial-refund">Reembolso parcial</Label>
            </div>

            {isPartialRefund && (
              <div>
                <Label htmlFor="refund-amount">Valor do Reembolso (R$)</Label>
                <Input
                  id="refund-amount"
                  type="number"
                  step="0.01"
                  max={selectedOrder?.total}
                  placeholder="0,00"
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(e.target.value)}
                  className="mt-1"
                  data-testid="input-refund-amount"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRefundOpen(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleRefundSubmit}
              disabled={!refundReason || requestRefundMutation.isPending}
              data-testid="button-confirm-refund"
            >
              {requestRefundMutation.isPending ? "Processando..." : "Confirmar Reembolso"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
