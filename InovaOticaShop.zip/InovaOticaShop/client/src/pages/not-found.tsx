import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-muted/30 p-4">
      <div className="flex items-center gap-2 mb-8">
        <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
          <Eye className="w-7 h-7 text-primary-foreground" />
        </div>
        <div className="flex flex-col">
          <span className="text-xl font-bold text-foreground leading-tight">Inova</span>
          <span className="text-sm text-accent font-semibold -mt-1">ÓTICA</span>
        </div>
      </div>

      <Card className="w-full max-w-md text-center">
        <CardContent className="pt-8 pb-6">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
            <span className="text-4xl font-bold text-muted-foreground">404</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Página não encontrada</h1>
          <p className="text-muted-foreground mb-6">
            A página que você está procurando não existe ou foi movida.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button variant="outline" onClick={() => window.history.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <Link href="/">
              <Button>
                <Home className="h-4 w-4 mr-2" />
                Ir para Início
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
