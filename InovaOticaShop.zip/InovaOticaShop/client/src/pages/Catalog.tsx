import { useState, useMemo } from "react";
import { useLocation, useSearch } from "wouter";
import { Search, SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductCard } from "@/components/ProductCard";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import type { Product } from "@shared/schema";
import { PRODUCT_TYPE_LABELS } from "@shared/schema";

const brands = ["Ray-Ban", "Oakley", "Prada", "Gucci", "Chilli Beans", "Vogue", "Armani", "Carrera"];
const colors = ["Preto", "Marrom", "Dourado", "Prata", "Azul", "Verde", "Tartaruga", "Rosa"];

type SortOption = "newest" | "price_asc" | "price_desc" | "name";

export default function Catalog() {
  const searchParams = useSearch();
  const [, setLocation] = useLocation();
  const urlParams = new URLSearchParams(searchParams);
  const initialType = urlParams.get("type") || "";
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTypes, setSelectedTypes] = useState<string[]>(initialType ? [initialType] : []);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000]);
  const [sortBy, setSortBy] = useState<SortOption>("newest");
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    
    return products
      .filter((product) => {
        if (searchQuery && !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
            !product.brand.toLowerCase().includes(searchQuery.toLowerCase())) {
          return false;
        }
        if (selectedTypes.length > 0 && !selectedTypes.includes(product.type)) {
          return false;
        }
        if (selectedBrands.length > 0 && !selectedBrands.includes(product.brand)) {
          return false;
        }
        if (selectedColors.length > 0 && !selectedColors.includes(product.color)) {
          return false;
        }
        if (product.price < priceRange[0] || product.price > priceRange[1]) {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "price_asc": return a.price - b.price;
          case "price_desc": return b.price - a.price;
          case "name": return a.name.localeCompare(b.name);
          default: return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
      });
  }, [products, searchQuery, selectedTypes, selectedBrands, selectedColors, priceRange, sortBy]);

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedTypes([]);
    setSelectedBrands([]);
    setSelectedColors([]);
    setPriceRange([0, 2000]);
    setLocation("/produtos");
  };

  const hasActiveFilters = searchQuery || selectedTypes.length > 0 || selectedBrands.length > 0 || 
                           selectedColors.length > 0 || priceRange[0] > 0 || priceRange[1] < 2000;

  const toggleArrayFilter = (value: string, array: string[], setArray: (arr: string[]) => void) => {
    if (array.includes(value)) {
      setArray(array.filter(v => v !== value));
    } else {
      setArray([...array, value]);
    }
  };

  const FiltersContent = () => (
    <div className="space-y-6">
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <span className="font-semibold text-foreground">Tipo</span>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 space-y-2">
          {Object.entries(PRODUCT_TYPE_LABELS).map(([value, label]) => (
            <label key={value} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={selectedTypes.includes(value)}
                onCheckedChange={() => toggleArrayFilter(value, selectedTypes, setSelectedTypes)}
                data-testid={`filter-type-${value}`}
              />
              <span className="text-sm">{label}</span>
            </label>
          ))}
        </CollapsibleContent>
      </Collapsible>

      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <span className="font-semibold text-foreground">Marca</span>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 space-y-2 max-h-48 overflow-y-auto">
          {brands.map((brand) => (
            <label key={brand} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={selectedBrands.includes(brand)}
                onCheckedChange={() => toggleArrayFilter(brand, selectedBrands, setSelectedBrands)}
                data-testid={`filter-brand-${brand.toLowerCase().replace(/\s/g, "-")}`}
              />
              <span className="text-sm">{brand}</span>
            </label>
          ))}
        </CollapsibleContent>
      </Collapsible>

      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <span className="font-semibold text-foreground">Cor</span>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 space-y-2">
          {colors.map((color) => (
            <label key={color} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={selectedColors.includes(color)}
                onCheckedChange={() => toggleArrayFilter(color, selectedColors, setSelectedColors)}
                data-testid={`filter-color-${color.toLowerCase()}`}
              />
              <span className="text-sm">{color}</span>
            </label>
          ))}
        </CollapsibleContent>
      </Collapsible>

      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <span className="font-semibold text-foreground">Preço</span>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-4 px-1">
          <Slider
            value={priceRange}
            onValueChange={(value) => setPriceRange(value as [number, number])}
            min={0}
            max={2000}
            step={50}
            className="mb-4"
            data-testid="filter-price-range"
          />
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>R$ {priceRange[0]}</span>
            <span>R$ {priceRange[1]}</span>
          </div>
        </CollapsibleContent>
      </Collapsible>

      {hasActiveFilters && (
        <Button variant="outline" onClick={clearFilters} className="w-full" data-testid="button-clear-filters">
          <X className="h-4 w-4 mr-2" />
          Limpar filtros
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-muted/30">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar óculos por nome ou marca..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <div className="flex gap-2">
              <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
                <SelectTrigger className="w-[180px]" data-testid="select-sort">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Mais recentes</SelectItem>
                  <SelectItem value="price_asc">Menor preço</SelectItem>
                  <SelectItem value="price_desc">Maior preço</SelectItem>
                  <SelectItem value="name">Nome A-Z</SelectItem>
                </SelectContent>
              </Select>

              <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                <SheetTrigger asChild className="lg:hidden">
                  <Button variant="outline" data-testid="button-mobile-filters">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Filtros
                    {hasActiveFilters && (
                      <Badge variant="default" className="ml-2 bg-accent">
                        {selectedTypes.length + selectedBrands.length + selectedColors.length}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[300px]">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FiltersContent />
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {hasActiveFilters && (
            <div className="flex flex-wrap gap-2 mb-6">
              {selectedTypes.map((type) => (
                <Badge key={type} variant="secondary" className="gap-1">
                  {PRODUCT_TYPE_LABELS[type]}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleArrayFilter(type, selectedTypes, setSelectedTypes)} />
                </Badge>
              ))}
              {selectedBrands.map((brand) => (
                <Badge key={brand} variant="secondary" className="gap-1">
                  {brand}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleArrayFilter(brand, selectedBrands, setSelectedBrands)} />
                </Badge>
              ))}
              {selectedColors.map((color) => (
                <Badge key={color} variant="secondary" className="gap-1">
                  {color}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleArrayFilter(color, selectedColors, setSelectedColors)} />
                </Badge>
              ))}
              {(priceRange[0] > 0 || priceRange[1] < 2000) && (
                <Badge variant="secondary" className="gap-1">
                  R$ {priceRange[0]} - R$ {priceRange[1]}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => setPriceRange([0, 2000])} />
                </Badge>
              )}
            </div>
          )}

          <div className="flex gap-8">
            <aside className="hidden lg:block w-64 flex-shrink-0">
              <Card>
                <CardContent className="p-4">
                  <h2 className="font-semibold text-lg mb-4 text-foreground">Filtros</h2>
                  <FiltersContent />
                </CardContent>
              </Card>
            </aside>

            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <p className="text-muted-foreground text-sm">
                  {isLoading ? "Carregando..." : `${filteredProducts.length} produto(s) encontrado(s)`}
                </p>
              </div>

              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i}>
                      <Skeleton className="aspect-square w-full" />
                      <CardContent className="p-4 space-y-3">
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-5 w-full" />
                        <Skeleton className="h-4 w-24" />
                        <div className="flex justify-between items-center">
                          <Skeleton className="h-6 w-20" />
                          <Skeleton className="h-9 w-9 rounded-md" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <Card className="p-12 text-center">
                  <p className="text-muted-foreground mb-4">
                    Nenhum produto encontrado com os filtros selecionados.
                  </p>
                  <Button variant="outline" onClick={clearFilters}>
                    Limpar filtros
                  </Button>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
