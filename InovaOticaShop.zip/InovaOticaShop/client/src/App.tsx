import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";
import { ThemeProvider } from "@/context/ThemeContext";

import Home from "@/pages/Home";
import Catalog from "@/pages/Catalog";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/not-found";

import AdminDashboard from "@/pages/admin/Dashboard";
import AdminSales from "@/pages/admin/Sales";
import AdminProducts from "@/pages/admin/Products";
import AdminCustomers from "@/pages/admin/Customers";
import AdminFinancial from "@/pages/admin/Financial";
import AdminPermissions from "@/pages/admin/Permissions";
import AdminRemovePermissions from "@/pages/admin/RemovePermissions";

function ProtectedRoute({ component: Component, minRole = 1 }: { component: React.ComponentType; minRole?: number }) {
  const { user, isLoading, isAdmin } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return <Redirect to="/login" />;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/produtos" component={Catalog} />
      <Route path="/carrinho" component={Cart} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/login" component={Login} />
      <Route path="/registrar" component={Register} />
      
      <Route path="/admin">
        <ProtectedRoute component={AdminDashboard} />
      </Route>
      <Route path="/admin/vendas">
        <ProtectedRoute component={AdminSales} minRole={2} />
      </Route>
      <Route path="/admin/produtos">
        <ProtectedRoute component={AdminProducts} minRole={3} />
      </Route>
      <Route path="/admin/clientes">
        <ProtectedRoute component={AdminCustomers} minRole={2} />
      </Route>
      <Route path="/admin/financeiro">
        <ProtectedRoute component={AdminFinancial} minRole={4} />
      </Route>
      <Route path="/admin/permissoes">
        <ProtectedRoute component={AdminPermissions} minRole={4} />
      </Route>
      <Route path="/admin/remover-permissoes">
        <ProtectedRoute component={AdminRemovePermissions} minRole={4} />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <CartProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </CartProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
