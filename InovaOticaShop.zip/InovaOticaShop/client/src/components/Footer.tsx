import { Link } from "wouter";
import { Eye, Phone, Mail, MapPin, Clock, Facebook, Instagram, Linkedin } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-accent">
                <Eye className="w-6 h-6 text-accent-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">Inova</span>
                <span className="text-xs text-accent font-semibold -mt-1">ÓTICA</span>
              </div>
            </Link>
            <p className="text-sm text-primary-foreground/80">
              Há mais de 20 anos cuidando da sua visão com qualidade, estilo e os melhores preços do mercado.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-accent transition-colors" aria-label="Facebook">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-accent transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-accent transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Links Rápidos</h3>
            <nav className="flex flex-col gap-2">
              <Link href="/produtos" className="text-sm text-primary-foreground/80 hover:text-accent transition-colors">
                Produtos
              </Link>
              <Link href="/produtos?type=sol" className="text-sm text-primary-foreground/80 hover:text-accent transition-colors">
                Óculos de Sol
              </Link>
              <Link href="/produtos?type=grau" className="text-sm text-primary-foreground/80 hover:text-accent transition-colors">
                Óculos de Grau
              </Link>
              <Link href="/produtos?type=esportivo" className="text-sm text-primary-foreground/80 hover:text-accent transition-colors">
                Óculos Esportivos
              </Link>
            </nav>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Atendimento</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-primary-foreground/80">
                <Phone className="w-4 h-4 text-accent" />
                <span>(11) 3456-7890</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-primary-foreground/80">
                <Mail className="w-4 h-4 text-accent" />
                <span>contato@inovaoptica.com.br</span>
              </div>
              <div className="flex items-start gap-3 text-sm text-primary-foreground/80">
                <Clock className="w-4 h-4 text-accent mt-0.5" />
                <div>
                  <p>Seg - Sex: 9h às 19h</p>
                  <p>Sáb: 9h às 14h</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Localização</h3>
            <div className="flex items-start gap-3 text-sm text-primary-foreground/80">
              <MapPin className="w-4 h-4 text-accent mt-0.5" />
              <div>
                <p>Av. Paulista, 1000</p>
                <p>Bela Vista - São Paulo/SP</p>
                <p>CEP: 01310-100</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-primary-foreground/60">
              {currentYear} Inova Ótica. Todos os direitos reservados.
            </p>
            <div className="flex gap-6">
              <Link href="/privacidade" className="text-sm text-primary-foreground/60 hover:text-accent transition-colors">
                Política de Privacidade
              </Link>
              <Link href="/termos" className="text-sm text-primary-foreground/60 hover:text-accent transition-colors">
                Termos de Uso
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
