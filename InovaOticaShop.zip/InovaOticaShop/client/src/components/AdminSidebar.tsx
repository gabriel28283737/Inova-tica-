import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Users,
  DollarSign,
  UserPlus,
  UserMinus,
  FileText,
  Settings,
  LogOut,
  Eye,
  ChevronLeft,
  Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAuth } from "@/context/AuthContext";
import { ROLES, ROLE_NAMES, ADMIN_EMAIL } from "@shared/schema";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/admin", minRole: ROLES.ESTAGIARIO },
  { icon: ShoppingCart, label: "Vendas", href: "/admin/vendas", minRole: ROLES.ATENDENTE },
  { icon: Package, label: "Produtos", href: "/admin/produtos", minRole: ROLES.VENDEDOR },
  { icon: Users, label: "Clientes", href: "/admin/clientes", minRole: ROLES.ATENDENTE },
  { icon: DollarSign, label: "Financeiro", href: "/admin/financeiro", minRole: ROLES.GERENTE },
  { icon: UserPlus, label: "Permissões", href: "/admin/permissoes", minRole: ROLES.GERENTE },
  { icon: UserMinus, label: "Remover Permissões", href: "/admin/remover-permissoes", minRole: ROLES.GERENTE },
  { icon: FileText, label: "Relatórios", href: "/admin/relatorios", minRole: ROLES.GERENTE },
  { icon: Settings, label: "Configurações", href: "/admin/configuracoes", minRole: ROLES.DONO },
];

function SidebarContentComponent() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { setOpenMobile } = useSidebar();

  const userRole = user?.email === ADMIN_EMAIL ? ROLES.ADMIN : (user?.role || 0);
  const roleName = user?.email === ADMIN_EMAIL ? "Administrador Principal" : ROLE_NAMES[userRole] || "Usuário";

  const filteredMenuItems = menuItems.filter(item => userRole >= item.minRole);

  const handleLinkClick = () => {
    setOpenMobile(false);
  };

  return (
    <>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <Link href="/" className="flex items-center gap-2" onClick={handleLinkClick}>
          <div className="flex items-center justify-center w-10 h-10 rounded-md bg-sidebar-primary">
            <Eye className="w-6 h-6 text-sidebar-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold text-sidebar-foreground leading-tight">Inova</span>
            <span className="text-xs text-sidebar-primary font-semibold -mt-1">ÓTICA</span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent className="py-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/60 text-xs uppercase tracking-wider px-4 mb-2">
            Menu Principal
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredMenuItems.map((item) => {
                const isActive = location === item.href || 
                  (item.href !== "/admin" && location.startsWith(item.href));
                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      className="mx-2"
                    >
                      <Link href={item.href} onClick={handleLinkClick} data-testid={`nav-admin-${item.label.toLowerCase().replace(/\s/g, "-")}`}>
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="mb-3">
          <p className="text-sm font-medium text-sidebar-foreground truncate">{user?.name}</p>
          <p className="text-xs text-sidebar-foreground/60 truncate">{user?.email}</p>
          <p className="text-xs text-sidebar-primary mt-1">{roleName}</p>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
          onClick={() => { logout(); handleLinkClick(); }}
          data-testid="button-admin-logout"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair
        </Button>
      </SidebarFooter>
    </>
  );
}

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

export function AdminLayout({ children, title, subtitle }: AdminLayoutProps) {
  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="border-r border-sidebar-border">
          <SidebarContentComponent />
        </Sidebar>
        
        <div className="flex flex-col flex-1 min-w-0">
          <header className="sticky top-0 z-40 flex items-center gap-4 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 h-14 md:px-6">
            <SidebarTrigger className="md:hidden" data-testid="button-sidebar-toggle">
              <Menu className="h-5 w-5" />
            </SidebarTrigger>
            <div className="flex-1">
              <h1 className="text-lg font-semibold text-foreground">{title}</h1>
              {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
            </div>
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ChevronLeft className="h-4 w-4" />
                <span className="hidden sm:inline">Voltar ao site</span>
              </Button>
            </Link>
          </header>
          
          <main className="flex-1 overflow-auto p-4 md:p-6">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
