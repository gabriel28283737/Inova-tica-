# Inova Ótica E-commerce

## Overview

Inova Ótica is a full-stack e-commerce platform for an optical shop specializing in eyeglasses (sun, prescription, and sports). The application features a public-facing storefront for customers to browse and purchase products, alongside a comprehensive admin dashboard for managing sales, inventory, customers, and business operations.

The platform is built with a modern TypeScript stack using React for the frontend and Express.js for the backend, with a PostgreSQL database for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- React 18 with TypeScript for type-safe component development
- Wouter for lightweight client-side routing
- Vite as the build tool and development server
- TanStack Query (React Query) for server state management and data fetching
- React Hook Form with Zod validation for form handling

**UI Component Library:**
- shadcn/ui components based on Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- Custom theme system supporting light/dark modes via ThemeContext
- Responsive design with mobile-first approach (320px-767px mobile, 768px-1023px tablet, 1024px+ desktop)

**State Management:**
- AuthContext: Manages user authentication state, login/logout, and role-based permissions
- CartContext: Handles shopping cart operations with localStorage persistence
- ThemeContext: Controls light/dark theme switching
- Local storage used for cart persistence and authentication tokens

**Design System:**
- Primary color palette: Dark Blue (#1a237e), Light Red (#ef5350), White for accents
- Clean, modern, minimalist aesthetic per design guidelines
- Consistent spacing using Tailwind units
- Custom border radius values (lg: 9px, md: 6px, sm: 3px)

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript
- HTTP server creation via Node's `http` module
- Middleware stack: JSON parsing, URL encoding, request logging

**API Structure:**
- RESTful API endpoints under `/api` prefix
- JWT-based authentication with Bearer tokens
- Role-based access control (RBAC) with 7 permission levels (Estagiário to Admin)
- Authentication middleware for protected routes
- Admin middleware with configurable minimum role requirements

**Session Management:**
- JWT tokens stored in localStorage on client
- Session secret configurable via environment variable
- Token verification on protected endpoints

### Data Layer

**Database:**
- PostgreSQL as the primary database (configured via DATABASE_URL)
- Drizzle ORM for type-safe database queries
- Schema defined in `shared/schema.ts` for shared type definitions
- Migration system using Drizzle Kit (output to `./migrations`)

**Data Models:**
- Users: Authentication, roles, and profile information
- Products: Catalog items with images, pricing, stock, categories (sun/prescription/sports)
- Orders: Purchase transactions with status tracking (pending → confirmed → separating → shipped → delivered/cancelled)
- Customers: Customer profiles with contact information and addresses
- CustomerObservations: Notes/comments attached to customer records
- Refunds: Return/refund processing workflow (requested → analyzing → approved → processed → completed/denied)
- Permissions: Admin user role assignments
- FinancialTransactions: Financial record tracking

**Storage Interface:**
- Abstract storage interface defined in `server/storage.ts`
- CRUD operations for all entity types
- Support for relationships (orders by customer, featured products, etc.)
- Special handling for admin user (ADMIN_EMAIL constant)

### Authentication & Authorization

**Role Hierarchy:**
1. Estagiário (Intern)
2. Atendente (Attendant)
3. Vendedor (Salesperson)
4. Gerente (Manager)
5. Sócio (Partner)
6. Dono (Owner)
7. Admin (System Administrator)

**Access Control:**
- JWT-based token authentication
- bcrypt for password hashing
- Role-based middleware protecting admin routes
- Special admin email with full system access
- Minimum role requirements per route/feature

### Payment & Checkout

**Payment Methods:**
- Credit Card
- Debit Card
- PIX (Brazilian instant payment)
- Boleto Bancário (Brazilian bank slip)

**Checkout Flow:**
- Multi-step form with Zod schema validation
- Customer information collection (name, CPF, email, phone)
- Complete address capture (street, number, complement, neighborhood, city, state, ZIP)
- Shopping cart with quantity management
- Subtotal, shipping, and total calculations
- Order creation with status tracking

### Build & Deployment

**Build Process:**
- Custom build script using esbuild for server bundling
- Vite for client-side bundling
- Bundle optimization via allowlist for frequently-used dependencies
- Separate dist outputs for client (`dist/public`) and server
- Production mode with NODE_ENV flag

**Development Environment:**
- Vite dev server with HMR (Hot Module Replacement)
- Development-only plugins (error overlay, cartographer, dev banner)
- File system restrictions for security
- TypeScript strict mode enabled

## External Dependencies

### Core Runtime Dependencies
- **@neondatabase/serverless**: PostgreSQL client optimized for serverless environments
- **drizzle-orm & drizzle-zod**: Type-safe ORM with Zod schema integration
- **express**: Web application framework
- **bcrypt**: Password hashing
- **jsonwebtoken**: JWT token generation and validation
- **zod**: Schema validation for forms and API contracts

### Frontend Libraries
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight routing
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Zod integration for form validation
- **date-fns**: Date manipulation
- **class-variance-authority & clsx**: Conditional className utilities
- **cmdk**: Command menu component

### UI Component Libraries
- Multiple **@radix-ui** packages: Headless UI primitives (dialog, dropdown, select, toast, etc.)
- **tailwindcss**: Utility-first CSS framework
- **tailwind-merge**: Merge Tailwind classes intelligently

### Build Tools
- **vite**: Frontend build tool and dev server
- **@vitejs/plugin-react**: React support for Vite
- **tsx**: TypeScript execution
- **esbuild**: JavaScript bundler for server code
- **drizzle-kit**: Database migration tool
- **typescript**: Type checking and compilation

### Additional Services
- Font loading from Google Fonts CDN (Inter, Open Sans, DM Sans, Fira Code, Geist Mono)
- Potential for chart visualization (Recharts/Chart.js mentioned in design guidelines)