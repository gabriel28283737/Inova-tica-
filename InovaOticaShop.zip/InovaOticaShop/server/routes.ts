import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { ADMIN_EMAIL, ROLES } from "@shared/schema";

const JWT_SECRET = process.env.SESSION_SECRET || "inova-optica-secret-key-2024";

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: number;
  };
}

const authMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) {
    return res.status(401).json({ message: "Token não fornecido" });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; email: string; role: number };
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ message: "Token inválido" });
  }
};

const adminMiddleware = (minRole: number = ROLES.ESTAGIARIO) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: "Não autenticado" });
    }
    
    const userRole = req.user.email === ADMIN_EMAIL ? ROLES.ADMIN : req.user.role;
    if (userRole < minRole) {
      return res.status(403).json({ message: "Permissão insuficiente" });
    }
    next();
  };
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { name, email, password } = req.body;
      
      if (!name || !email || !password) {
        return res.status(400).json({ message: "Dados incompletos" });
      }

      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "E-mail já cadastrado" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        role: 0,
      });

      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: "7d" }
      );

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      res.status(500).json({ message: "Erro ao registrar usuário" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Dados incompletos" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "E-mail ou senha incorretos" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "E-mail ou senha incorretos" });
      }

      const permission = await storage.getPermissionByEmail(email);
      const role = email === ADMIN_EMAIL ? ROLES.ADMIN : (permission?.role || user.role || 0);

      if (permission && permission.role !== user.role) {
        await storage.updateUser(user.id, { role: permission.role });
        user.role = permission.role;
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role },
        JWT_SECRET,
        { expiresIn: "7d" }
      );

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: { ...userWithoutPassword, role }, token });
    } catch (error) {
      res.status(500).json({ message: "Erro ao fazer login" });
    }
  });

  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar produtos" });
    }
  });

  app.get("/api/products/featured", async (req, res) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar produtos em destaque" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar produto" });
    }
  });

  app.post("/api/products", authMiddleware, adminMiddleware(ROLES.VENDEDOR), async (req: AuthRequest, res) => {
    try {
      const product = await storage.createProduct(req.body);
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar produto" });
    }
  });

  app.patch("/api/products/:id", authMiddleware, adminMiddleware(ROLES.VENDEDOR), async (req: AuthRequest, res) => {
    try {
      const product = await storage.updateProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar produto" });
    }
  });

  app.delete("/api/products/:id", authMiddleware, adminMiddleware(ROLES.VENDEDOR), async (req: AuthRequest, res) => {
    try {
      const deleted = await storage.deleteProduct(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Produto não encontrado" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover produto" });
    }
  });

  app.get("/api/orders", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar pedidos" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = req.body;
      
      let customer = await storage.getCustomerByEmail(orderData.customerEmail);
      if (!customer) {
        customer = await storage.createCustomer({
          name: orderData.customerName,
          email: orderData.customerEmail,
          phone: orderData.customerPhone,
          cpf: orderData.customerCpf,
          address: orderData.shippingAddress,
        });
      }

      const order = await storage.createOrder({
        ...orderData,
        customerId: customer.id,
        status: "pending",
      });

      await storage.updateCustomer(customer.id, {
        totalOrders: (customer.totalOrders || 0) + 1,
        totalSpent: (customer.totalSpent || 0) + order.total,
      });

      await storage.createFinancialTransaction({
        type: "income",
        category: "Vendas",
        description: `Pedido #${order.orderNumber}`,
        amount: order.total,
        orderId: order.id,
      });

      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar pedido" });
    }
  });

  app.patch("/api/orders/:id/status", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const { status } = req.body;
      const order = await storage.updateOrder(req.params.id, { status });
      if (!order) {
        return res.status(404).json({ message: "Pedido não encontrado" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar status do pedido" });
    }
  });

  app.get("/api/customers", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar clientes" });
    }
  });

  app.post("/api/customers/:id/observations", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const { content } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!content || !user) {
        return res.status(400).json({ message: "Dados incompletos" });
      }

      const observation = await storage.addCustomerObservation(req.params.id, {
        content,
        authorId: user.id,
        authorName: user.name,
        authorEmail: user.email,
      });

      res.status(201).json(observation);
    } catch (error) {
      res.status(500).json({ message: "Erro ao adicionar observação" });
    }
  });

  app.patch("/api/customers/:customerId/observations/:observationId", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const { content } = req.body;
      const observation = await storage.updateCustomerObservation(
        req.params.customerId,
        req.params.observationId,
        content
      );

      if (!observation) {
        return res.status(404).json({ message: "Observação não encontrada" });
      }

      res.json(observation);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar observação" });
    }
  });

  app.delete("/api/customers/:customerId/observations/:observationId", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const deleted = await storage.deleteCustomerObservation(
        req.params.customerId,
        req.params.observationId
      );

      if (!deleted) {
        return res.status(404).json({ message: "Observação não encontrada" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover observação" });
    }
  });

  app.get("/api/refunds", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const refunds = await storage.getRefunds();
      res.json(refunds);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar reembolsos" });
    }
  });

  app.post("/api/refunds", authMiddleware, adminMiddleware(ROLES.ATENDENTE), async (req: AuthRequest, res) => {
    try {
      const { orderId, reason, amount, isPartial } = req.body;
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Pedido não encontrado" });
      }

      const customer = await storage.getCustomer(order.customerId);

      const refund = await storage.createRefund({
        orderId,
        orderNumber: order.orderNumber,
        customerId: order.customerId,
        customerName: customer?.name || order.customerName,
        reason,
        amount,
        isPartial,
        status: "requested",
      });

      res.status(201).json(refund);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar reembolso" });
    }
  });

  app.patch("/api/refunds/:id", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      const refund = await storage.updateRefund(req.params.id, {
        ...req.body,
        processedBy: req.user!.id,
        processedByName: user?.name,
      });

      if (!refund) {
        return res.status(404).json({ message: "Reembolso não encontrado" });
      }

      res.json(refund);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar reembolso" });
    }
  });

  app.get("/api/permissions", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const permissions = await storage.getPermissions();
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar permissões" });
    }
  });

  app.post("/api/permissions", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const { email, name, role } = req.body;
      
      const userRole = req.user!.email === ADMIN_EMAIL ? ROLES.ADMIN : req.user!.role;
      
      if (role > userRole) {
        return res.status(403).json({ message: "Não é possível adicionar um cargo superior ao seu" });
      }

      if (email === ADMIN_EMAIL) {
        return res.status(403).json({ message: "Não é possível modificar permissões do administrador principal" });
      }

      const existingPermission = await storage.getPermissionByEmail(email);
      if (existingPermission) {
        return res.status(400).json({ message: "Usuário já possui permissões" });
      }

      const addedByUser = await storage.getUser(req.user!.id);

      let user = await storage.getUserByEmail(email);
      if (!user) {
        const hashedPassword = await bcrypt.hash("123456", 10);
        user = await storage.createUser({
          name,
          email,
          password: hashedPassword,
          role,
        });
      } else {
        await storage.updateUser(user.id, { role });
      }

      const permission = await storage.createPermission({
        userId: user.id,
        userName: name,
        userEmail: email,
        role,
        addedById: req.user!.id,
        addedByName: addedByUser?.name || "Sistema",
        addedByEmail: req.user!.email,
      });

      res.status(201).json(permission);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar permissão" });
    }
  });

  app.delete("/api/permissions/:id", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const permission = await storage.getPermission(req.params.id);
      if (!permission) {
        return res.status(404).json({ message: "Permissão não encontrada" });
      }

      if (permission.userEmail === ADMIN_EMAIL) {
        return res.status(403).json({ message: "Não é possível remover o administrador principal" });
      }

      const userRole = req.user!.email === ADMIN_EMAIL ? ROLES.ADMIN : req.user!.role;
      if (permission.role >= userRole && req.user!.email !== ADMIN_EMAIL) {
        return res.status(403).json({ message: "Não é possível remover um cargo igual ou superior ao seu" });
      }

      const removerUser = await storage.getUser(req.user!.id);
      await storage.updatePermission(req.params.id, {
        isActive: false,
        removedAt: new Date().toISOString(),
        removedById: req.user!.id,
        removedByName: removerUser?.name,
      });

      const user = await storage.getUserByEmail(permission.userEmail);
      if (user) {
        await storage.updateUser(user.id, { role: 0 });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Erro ao remover permissão" });
    }
  });

  app.get("/api/financial/transactions", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const transactions = await storage.getFinancialTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar transações" });
    }
  });

  app.post("/api/financial/transactions", authMiddleware, adminMiddleware(ROLES.GERENTE), async (req: AuthRequest, res) => {
    try {
      const transaction = await storage.createFinancialTransaction(req.body);
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar transação" });
    }
  });

  return httpServer;
}
