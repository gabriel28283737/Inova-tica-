import type { 
  User, InsertUser, 
  Product, InsertProduct,
  Order, InsertOrder,
  Customer, InsertCustomer, CustomerObservation,
  Refund, InsertRefund,
  Permission, InsertPermission,
  FinancialTransaction, InsertFinancialTransaction
} from "@shared/schema";
import { ADMIN_EMAIL, ROLES } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  
  getProducts(): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrdersByCustomer(customerId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, order: Partial<Order>): Promise<Order | undefined>;
  
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<Customer>): Promise<Customer | undefined>;
  addCustomerObservation(customerId: string, observation: Omit<CustomerObservation, "id" | "createdAt">): Promise<CustomerObservation>;
  updateCustomerObservation(customerId: string, observationId: string, content: string): Promise<CustomerObservation | undefined>;
  deleteCustomerObservation(customerId: string, observationId: string): Promise<boolean>;
  
  getRefunds(): Promise<Refund[]>;
  getRefund(id: string): Promise<Refund | undefined>;
  createRefund(refund: InsertRefund): Promise<Refund>;
  updateRefund(id: string, refund: Partial<Refund>): Promise<Refund | undefined>;
  
  getPermissions(): Promise<Permission[]>;
  getPermission(id: string): Promise<Permission | undefined>;
  getPermissionByEmail(email: string): Promise<Permission | undefined>;
  createPermission(permission: InsertPermission): Promise<Permission>;
  updatePermission(id: string, permission: Partial<Permission>): Promise<Permission | undefined>;
  deletePermission(id: string): Promise<boolean>;
  
  getFinancialTransactions(): Promise<FinancialTransaction[]>;
  createFinancialTransaction(transaction: InsertFinancialTransaction): Promise<FinancialTransaction>;
}

function generateOrderNumber(): string {
  const date = new Date();
  const year = date.getFullYear().toString().slice(-2);
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, "0");
  return `${year}${month}${day}${random}`;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private orders: Map<string, Order>;
  private customers: Map<string, Customer>;
  private refunds: Map<string, Refund>;
  private permissions: Map<string, Permission>;
  private financialTransactions: Map<string, FinancialTransaction>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.customers = new Map();
    this.refunds = new Map();
    this.permissions = new Map();
    this.financialTransactions = new Map();
    
    this.initializeData();
  }

  private initializeData() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Ray-Ban Aviator Classic",
        description: "O ícone atemporal dos óculos de sol. Armação de metal dourado com lentes verdes clássicas G-15.",
        price: 699.00,
        type: "sol",
        brand: "Ray-Ban",
        color: "Dourado",
        image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&h=500&fit=crop",
        stock: 25,
        featured: true,
      },
      {
        name: "Oakley Holbrook",
        description: "Design moderno com tecnologia de alta performance. Ideal para uso diário e esportes.",
        price: 549.00,
        type: "sol",
        brand: "Oakley",
        color: "Preto",
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500&h=500&fit=crop",
        stock: 18,
        featured: true,
      },
      {
        name: "Prada VPR 01TV",
        description: "Armação de grau sofisticada com design italiano contemporâneo. Perfeita para o dia a dia.",
        price: 1299.00,
        type: "grau",
        brand: "Prada",
        color: "Tartaruga",
        image: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=500&h=500&fit=crop",
        stock: 12,
        featured: true,
      },
      {
        name: "Oakley Radar EV",
        description: "Desenvolvido para atletas. Lentes com tecnologia Prizm para máxima clareza visual.",
        price: 899.00,
        type: "esportivo",
        brand: "Oakley",
        color: "Azul",
        image: "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=500&h=500&fit=crop",
        stock: 8,
        featured: true,
      },
      {
        name: "Gucci GG0010S",
        description: "Elegância e sofisticação em um modelo oversized. Lentes degradê marrom.",
        price: 1899.00,
        type: "sol",
        brand: "Gucci",
        color: "Marrom",
        image: "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=500&h=500&fit=crop",
        stock: 6,
        featured: false,
      },
      {
        name: "Chilli Beans Flash",
        description: "Estilo jovem e moderno. Armação resistente com lentes espelhadas.",
        price: 249.00,
        type: "sol",
        brand: "Chilli Beans",
        color: "Rosa",
        image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=500&h=500&fit=crop",
        stock: 30,
        featured: false,
      },
      {
        name: "Vogue VO5286",
        description: "Armação feminina delicada em acetato. Design moderno e confortável.",
        price: 399.00,
        type: "grau",
        brand: "Vogue",
        color: "Preto",
        image: "https://images.unsplash.com/photo-1577803645773-f96470509666?w=500&h=500&fit=crop",
        stock: 20,
        featured: false,
      },
      {
        name: "Armani EA4033",
        description: "Clássico masculino com armação em metal. Ideal para ocasiões formais.",
        price: 749.00,
        type: "sol",
        brand: "Armani",
        color: "Prata",
        image: "https://images.unsplash.com/photo-1591076482161-42ce6da69f67?w=500&h=500&fit=crop",
        stock: 15,
        featured: true,
      },
    ];

    sampleProducts.forEach((product) => {
      const id = randomUUID();
      this.products.set(id, {
        ...product,
        id,
        createdAt: new Date().toISOString(),
      });
    });

    const adminUser: User = {
      id: randomUUID(),
      email: ADMIN_EMAIL,
      password: "$2b$10$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4M4ysLc.Z8oJj9li",
      name: "Administrador Principal",
      role: ROLES.ADMIN,
      createdAt: new Date().toISOString(),
    };
    this.users.set(adminUser.id, adminUser);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, role: insertUser.role || 0, createdAt: new Date().toISOString() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter((p) => p.featured);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id, createdAt: new Date().toISOString() };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    const updated = { ...product, ...updates };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersByCustomer(customerId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter((o) => o.customerId === customerId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const orderNumber = generateOrderNumber();
    const now = new Date().toISOString();
    const order: Order = { 
      ...insertOrder, 
      id, 
      orderNumber,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    const updated = { ...order, ...updates, updatedAt: new Date().toISOString() };
    this.orders.set(id, updated);
    return updated;
  }

  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find((c) => c.email === email);
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = randomUUID();
    const customer: Customer = { 
      ...insertCustomer, 
      id, 
      observations: [],
      totalOrders: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString(),
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: string, updates: Partial<Customer>): Promise<Customer | undefined> {
    const customer = this.customers.get(id);
    if (!customer) return undefined;
    const updated = { ...customer, ...updates };
    this.customers.set(id, updated);
    return updated;
  }

  async addCustomerObservation(customerId: string, observation: Omit<CustomerObservation, "id" | "createdAt">): Promise<CustomerObservation> {
    const customer = this.customers.get(customerId);
    if (!customer) throw new Error("Customer not found");
    
    const newObservation: CustomerObservation = {
      ...observation,
      id: randomUUID(),
      createdAt: new Date().toISOString(),
    };
    
    customer.observations = [newObservation, ...(customer.observations || [])];
    this.customers.set(customerId, customer);
    return newObservation;
  }

  async updateCustomerObservation(customerId: string, observationId: string, content: string): Promise<CustomerObservation | undefined> {
    const customer = this.customers.get(customerId);
    if (!customer) return undefined;
    
    const observationIndex = customer.observations?.findIndex((o) => o.id === observationId);
    if (observationIndex === undefined || observationIndex === -1) return undefined;
    
    customer.observations[observationIndex] = {
      ...customer.observations[observationIndex],
      content,
      updatedAt: new Date().toISOString(),
    };
    
    this.customers.set(customerId, customer);
    return customer.observations[observationIndex];
  }

  async deleteCustomerObservation(customerId: string, observationId: string): Promise<boolean> {
    const customer = this.customers.get(customerId);
    if (!customer) return false;
    
    const initialLength = customer.observations?.length || 0;
    customer.observations = customer.observations?.filter((o) => o.id !== observationId) || [];
    
    if (customer.observations.length < initialLength) {
      this.customers.set(customerId, customer);
      return true;
    }
    return false;
  }

  async getRefunds(): Promise<Refund[]> {
    return Array.from(this.refunds.values());
  }

  async getRefund(id: string): Promise<Refund | undefined> {
    return this.refunds.get(id);
  }

  async createRefund(insertRefund: InsertRefund): Promise<Refund> {
    const id = randomUUID();
    const now = new Date().toISOString();
    const refund: Refund = { 
      ...insertRefund, 
      id,
      status: "requested",
      createdAt: now,
      updatedAt: now,
    };
    this.refunds.set(id, refund);
    return refund;
  }

  async updateRefund(id: string, updates: Partial<Refund>): Promise<Refund | undefined> {
    const refund = this.refunds.get(id);
    if (!refund) return undefined;
    const updated = { ...refund, ...updates, updatedAt: new Date().toISOString() };
    this.refunds.set(id, updated);
    return updated;
  }

  async getPermissions(): Promise<Permission[]> {
    return Array.from(this.permissions.values());
  }

  async getPermission(id: string): Promise<Permission | undefined> {
    return this.permissions.get(id);
  }

  async getPermissionByEmail(email: string): Promise<Permission | undefined> {
    return Array.from(this.permissions.values()).find((p) => p.userEmail === email && p.isActive);
  }

  async createPermission(insertPermission: InsertPermission): Promise<Permission> {
    const id = randomUUID();
    const permission: Permission = { 
      ...insertPermission, 
      id,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    this.permissions.set(id, permission);
    return permission;
  }

  async updatePermission(id: string, updates: Partial<Permission>): Promise<Permission | undefined> {
    const permission = this.permissions.get(id);
    if (!permission) return undefined;
    const updated = { ...permission, ...updates };
    this.permissions.set(id, updated);
    return updated;
  }

  async deletePermission(id: string): Promise<boolean> {
    const permission = this.permissions.get(id);
    if (!permission) return false;
    permission.isActive = false;
    permission.removedAt = new Date().toISOString();
    this.permissions.set(id, permission);
    return true;
  }

  async getFinancialTransactions(): Promise<FinancialTransaction[]> {
    return Array.from(this.financialTransactions.values());
  }

  async createFinancialTransaction(insertTransaction: InsertFinancialTransaction): Promise<FinancialTransaction> {
    const id = randomUUID();
    const transaction: FinancialTransaction = { 
      ...insertTransaction, 
      id,
      createdAt: new Date().toISOString(),
    };
    this.financialTransactions.set(id, transaction);
    return transaction;
  }
}

export const storage = new MemStorage();
