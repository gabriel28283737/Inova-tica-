# Inova Ótica E-commerce - Design Guidelines

## Color Palette
**Primary Colors:**
- Dark Blue: `#1a237e` (or similar)
- Light Red: `#ef5350` (or similar)
- White: `#ffffff` (borders and contrast elements)

**Design Philosophy:** Clean, modern, minimalist aesthetic

## Typography
- Modern, readable font family (Google Fonts via CDN)
- Clear hierarchy for headings, body text, and UI elements

## Layout System
**Responsive Breakpoints:**
- Mobile: 320px - 767px (hamburger menu required)
- Tablet: 768px - 1023px
- Desktop: 1024px+

**Spacing:** Consistent Tailwind units for padding and margins across all components

## Core Components

### Public Pages
**Landing Page (Home):**
- Hero banner showcasing eyeglasses (large hero image)
- Header with Inova Ótica logo and navigation
- Featured products section with cards
- Information section about the optical shop
- Prominent "Adquirir" CTA button → redirects to sales page
- Footer with contact information

**Product Catalog/Sales Page:**
- Product cards: image, name, price, "Comprar" button
- Filter sidebar: type (sun/prescription/sports), brand, price, color
- Functional search bar
- Shopping cart interface
- Complete checkout flow with client data form (name, CPF, email, phone, full address)
- Payment options display: credit/debit card, PIX, boleto

### Admin Dashboard Components
**Sidebar Navigation:**
- Dashboard, Vendas, Produtos, Clientes, Financeiro, Permissões, Remover Permissões, Relatórios, Configurações, Sair

**Dashboard Widgets:**
- Sales graphs using Recharts/Chart.js (daily, weekly, monthly, annual)
- Visual indicators in brand colors (dark blue and light red)
- KPI cards: total sales (R$), order count, average ticket, top products
- Line chart for sales evolution
- Pie chart for category distribution
- Period filters

**Sales Management:**
- Order list with status badges (Pendente, Confirmado, Em separação, Enviado, Entregue, Cancelado)
- Filters and search functionality
- Status change buttons
- Refund modal with confirmation checkbox and reason field

**Client Management:**
- Client list with search
- Detailed observation system with cards showing: content, timestamp, author name/email
- Observation history with edit/delete capabilities

**Permission Management:**
- Add permissions: form with email field, hierarchical dropdown (shows only equal/lower ranks), name field
- Permission history cards displaying: adder name/email, added user name/email, role, timestamp, active status
- Remove permissions: user list with role display, confirmation modal with checkbox

**Financial Dashboard:**
- Account balance, revenue, expenses, net profit displays
- Cash flow visualization
- Monthly/annual financial graphs

## Visual Elements
**Cards:** Alternating backgrounds (light dark blue and white) with white borders

**Forms:** Clean, organized fields with clear labels

**Modals:** Confirmation dialogs with titles, descriptive text, checkbox confirmations, color-coded buttons (cancel in gray, confirm in red for destructive actions)

**Buttons:** Background blur effect when placed on images, clear hover states

**Icons:** React Icons library throughout interface

**Notifications:** React Toastify for success/error messages

**Loading States:** Visual indicators for all async operations

## Images
- Hero image: Large banner showcasing eyeglasses/optical products on landing page
- Product images: Clear product photography in catalog cards
- Logo: Inova Ótica branding (use placeholder if needed)
- Optional: Team/store photos in about section

## Accessibility & UX
- Clear error and validation messages on all forms
- Pagination on all lists
- Horizontal scroll for tables on mobile
- Touch-optimized form inputs
- Dark mode toggle (optional feature)