import { z } from "zod";

export const ROLES = {
  ESTAGIARIO: 1,
  ATENDENTE: 2,
  VENDEDOR: 3,
  GERENTE: 4,
  SOCIO: 5,
  DONO: 6,
  ADMIN: 7,
} as const;

export const ROLE_NAMES: Record<number, string> = {
  1: "Estagiário",
  2: "Atendente",
  3: "Vendedor",
  4: "Gerente",
  5: "Sócio",
  6: "Dono",
  7: "Administrador Principal",
};

export const ADMIN_EMAIL = "admin@inovaoptica.com.br";

export const ORDER_STATUS = {
  PENDING: "pending",
  CONFIRMED: "confirmed",
  SEPARATING: "separating",
  SHIPPED: "shipped",
  DELIVERED: "delivered",
  CANCELLED: "cancelled",
} as const;

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: "Pendente",
  confirmed: "Confirmado",
  separating: "Em separação",
  shipped: "Enviado",
  delivered: "Entregue",
  cancelled: "Cancelado",
};

export const REFUND_STATUS = {
  REQUESTED: "requested",
  ANALYZING: "analyzing",
  APPROVED: "approved",
  PROCESSED: "processed",
  COMPLETED: "completed",
  DENIED: "denied",
} as const;

export const REFUND_STATUS_LABELS: Record<string, string> = {
  requested: "Solicitado",
  analyzing: "Em análise",
  approved: "Aprovado",
  processed: "Processado",
  completed: "Concluído",
  denied: "Negado",
};

export const PAYMENT_METHODS = {
  CREDIT_CARD: "credit_card",
  DEBIT_CARD: "debit_card",
  PIX: "pix",
  BOLETO: "boleto",
} as const;

export const PAYMENT_METHOD_LABELS: Record<string, string> = {
  credit_card: "Cartão de Crédito",
  debit_card: "Cartão de Débito",
  pix: "PIX",
  boleto: "Boleto",
};

export const PRODUCT_TYPES = {
  SOL: "sol",
  GRAU: "grau",
  ESPORTIVO: "esportivo",
} as const;

export const PRODUCT_TYPE_LABELS: Record<string, string> = {
  sol: "Óculos de Sol",
  grau: "Óculos de Grau",
  esportivo: "Óculos Esportivo",
};

export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  password: z.string(),
  name: z.string(),
  role: z.number().min(0).max(7),
  phone: z.string().optional(),
  cpf: z.string().optional(),
  address: z.object({
    street: z.string(),
    number: z.string(),
    complement: z.string().optional(),
    neighborhood: z.string(),
    city: z.string(),
    state: z.string(),
    zipCode: z.string(),
  }).optional(),
  createdAt: z.string(),
});

export const insertUserSchema = userSchema.omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = z.infer<typeof userSchema>;

export const productSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  price: z.number(),
  type: z.enum(["sol", "grau", "esportivo"]),
  brand: z.string(),
  color: z.string(),
  image: z.string(),
  stock: z.number(),
  featured: z.boolean().default(false),
  createdAt: z.string(),
});

export const insertProductSchema = productSchema.omit({ id: true, createdAt: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = z.infer<typeof productSchema>;

export const orderItemSchema = z.object({
  productId: z.string(),
  productName: z.string(),
  quantity: z.number(),
  price: z.number(),
});

export type OrderItem = z.infer<typeof orderItemSchema>;

export const orderSchema = z.object({
  id: z.string(),
  orderNumber: z.string(),
  customerId: z.string(),
  customerName: z.string(),
  customerEmail: z.string(),
  customerPhone: z.string(),
  customerCpf: z.string(),
  shippingAddress: z.object({
    street: z.string(),
    number: z.string(),
    complement: z.string().optional(),
    neighborhood: z.string(),
    city: z.string(),
    state: z.string(),
    zipCode: z.string(),
  }),
  items: z.array(orderItemSchema),
  subtotal: z.number(),
  shipping: z.number(),
  total: z.number(),
  paymentMethod: z.string(),
  status: z.string(),
  trackingCode: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export const insertOrderSchema = orderSchema.omit({ id: true, orderNumber: true, createdAt: true, updatedAt: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = z.infer<typeof orderSchema>;

export const customerObservationSchema = z.object({
  id: z.string(),
  content: z.string(),
  authorId: z.string(),
  authorName: z.string(),
  authorEmail: z.string(),
  createdAt: z.string(),
  updatedAt: z.string().optional(),
});

export type CustomerObservation = z.infer<typeof customerObservationSchema>;

export const customerSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  cpf: z.string(),
  address: z.object({
    street: z.string(),
    number: z.string(),
    complement: z.string().optional(),
    neighborhood: z.string(),
    city: z.string(),
    state: z.string(),
    zipCode: z.string(),
  }),
  observations: z.array(customerObservationSchema).default([]),
  totalOrders: z.number().default(0),
  totalSpent: z.number().default(0),
  createdAt: z.string(),
});

export const insertCustomerSchema = customerSchema.omit({ id: true, createdAt: true, observations: true, totalOrders: true, totalSpent: true });
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = z.infer<typeof customerSchema>;

export const refundSchema = z.object({
  id: z.string(),
  orderId: z.string(),
  orderNumber: z.string(),
  customerId: z.string(),
  customerName: z.string(),
  reason: z.string(),
  amount: z.number(),
  isPartial: z.boolean(),
  status: z.string(),
  processedBy: z.string().optional(),
  processedByName: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export const insertRefundSchema = refundSchema.omit({ id: true, createdAt: true, updatedAt: true, processedBy: true, processedByName: true });
export type InsertRefund = z.infer<typeof insertRefundSchema>;
export type Refund = z.infer<typeof refundSchema>;

export const permissionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  userName: z.string(),
  userEmail: z.string(),
  role: z.number(),
  addedById: z.string(),
  addedByName: z.string(),
  addedByEmail: z.string(),
  isActive: z.boolean().default(true),
  createdAt: z.string(),
  removedAt: z.string().optional(),
  removedById: z.string().optional(),
  removedByName: z.string().optional(),
});

export const insertPermissionSchema = permissionSchema.omit({ id: true, createdAt: true, isActive: true });
export type InsertPermission = z.infer<typeof insertPermissionSchema>;
export type Permission = z.infer<typeof permissionSchema>;

export const financialTransactionSchema = z.object({
  id: z.string(),
  type: z.enum(["income", "expense"]),
  category: z.string(),
  description: z.string(),
  amount: z.number(),
  orderId: z.string().optional(),
  createdAt: z.string(),
});

export const insertFinancialTransactionSchema = financialTransactionSchema.omit({ id: true, createdAt: true });
export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;
export type FinancialTransaction = z.infer<typeof financialTransactionSchema>;

export const cartItemSchema = z.object({
  product: productSchema,
  quantity: z.number(),
});

export type CartItem = z.infer<typeof cartItemSchema>;

export const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const registerSchema = z.object({
  name: z.string().min(2, "Nome deve ter no mínimo 2 caracteres"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não conferem",
  path: ["confirmPassword"],
});

export type RegisterInput = z.infer<typeof registerSchema>;

export const checkoutSchema = z.object({
  name: z.string().min(2, "Nome obrigatório"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(10, "Telefone inválido"),
  cpf: z.string().min(11, "CPF inválido"),
  street: z.string().min(3, "Endereço obrigatório"),
  number: z.string().min(1, "Número obrigatório"),
  complement: z.string().optional(),
  neighborhood: z.string().min(2, "Bairro obrigatório"),
  city: z.string().min(2, "Cidade obrigatória"),
  state: z.string().min(2, "Estado obrigatório"),
  zipCode: z.string().min(8, "CEP inválido"),
  paymentMethod: z.string().min(1, "Selecione uma forma de pagamento"),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
